from odoo import _, api, fields, models


class EventCancelWizard(models.TransientModel):
    _name = "event.cancel.wizard"
    _description = "Event Cancel Wizard"

    event_id = fields.Many2one("event.event", required=True, readonly=True)
    target_stage_id = fields.Many2one("event.stage", required=True, readonly=True)
    attendee_count = fields.Integer(readonly=True)
    refund_points = fields.Boolean(string="Refund all attendee credits", default=True)

    @api.model
    def default_get(self, fields_list):
        values = super().default_get(fields_list)
        event = self.env["event.event"].browse(self.env.context.get("default_event_id"))
        target_stage = self.env["event.stage"].browse(self.env.context.get("default_target_stage_id"))
        if not event.exists() or not target_stage.exists():
            return values
        values.update({
            "event_id": event.id,
            "target_stage_id": target_stage.id,
            "attendee_count": int(getattr(event, "seats_taken", 0) or 0),
        })
        return values

    def _refund_and_cancel_registrations(self, event, refund_points):
        registrations = self.env["event.registration"].with_context(active_test=False).search([
            ("event_id", "=", event.id),
        ])
        if not registrations:
            return

        wallet_model = self.env["event.points.wallet"].sudo() if "event.points.wallet" in self.env else False
        if refund_points and wallet_model:
            for registration in registrations:
                if not registration.partner_id:
                    continue
                points = 0
                if "points_spent" in registration._fields:
                    points = int(registration.points_spent or 0)
                elif registration.event_ticket_id and "point_cost" in registration.event_ticket_id._fields:
                    points = int(registration.event_ticket_id.point_cost or 0)
                if points > 0:
                    wallet = wallet_model.get_or_create_wallet(registration.partner_id)
                    wallet.add_points(points, _("Event cancellation refund"), reference=event.name)
                    if "points_spent" in registration._fields:
                        registration.sudo().write({"points_spent": 0})

        if hasattr(registrations, "action_cancel"):
            registrations.action_cancel()
        else:
            registrations.sudo().write({"state": "cancel"})

    def action_confirm_cancel(self):
        self.ensure_one()
        event = self.event_id.sudo()
        self._refund_and_cancel_registrations(event, self.refund_points)

        vals = {"stage_id": self.target_stage_id.id}
        if "website_published" in event._fields:
            vals["website_published"] = False
        if "is_published" in event._fields:
            vals["is_published"] = False
        event.write(vals)
        return {
            "type": "ir.actions.act_window_close",
            "infos": {"stage_updated": True},
        }
