import base64
from datetime import datetime
import json
import secrets
import re

from urllib.parse import quote_plus
from urllib.parse import urlencode

import pytz
import logging
from urllib.parse import urlparse

from odoo import fields, http
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.tools import html2plaintext
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

class EventApplicationPortal(CustomerPortal):
    def _portal_stage_ids(self, stage_scope):
        stage_names_map = {
            'live': {"new", "booked", "announced"},
            'past': {"ended", "cancelled"},
        }
        wanted_names = stage_names_map.get(stage_scope) or set()
        if not wanted_names:
            return []
        stages = request.env["event.stage"].sudo().search([])
        return stages.filtered(
            lambda stage: (stage.name or "").strip().lower() in wanted_names
        ).ids

    def _my_event_domain(self, partner, *, published_only=False, stage_scope=None):
        domain = [
            '|',
            ('organizer_id', '=', partner.id),
            ('application_id.partner_id', '=', partner.id),
            ('active', '=', True),
        ]
        if published_only:
            domain += ['|', ('website_published', '=', True), ('is_published', '=', True)]
        if stage_scope:
            stage_ids = self._portal_stage_ids(stage_scope)
            if stage_ids:
                domain.append(('stage_id', 'in', stage_ids))
            else:
                domain.append(('id', '=', 0))
        return domain

    def _normalize_online_link(self, raw_link):
        link = (raw_link or '').strip()
        if not link:
            return False
        parsed = urlparse(link)
        if not parsed.scheme:
            link = f"https://{link}"
        return link

    def _normalize_text_value(self, value):
        if value is None:
            return False
        value = str(value).strip()
        return value or False

    def _validate_zip_code(self, country_id, zip_code):
        zip_code = self._normalize_text_value(zip_code)
        if not country_id or not zip_code:
            return True
        country = request.env['res.country'].sudo().browse(int(country_id))
        if not country.exists():
            return True
        if country.code == 'US':
            return bool(re.match(r'^\d{5}(-\d{4})?$', zip_code))
        if country.code == 'CA':
            return bool(re.match(r'^[A-Za-z]\d[A-Za-z]\s?\d[A-Za-z]\d$', zip_code))
        return True

    def _registration_owner_domain(self):
        partner = request.env.user.partner_id
        user_email = (request.env.user.email or partner.email or '').strip()
        domain = [('partner_id', '=', partner.id)]
        if user_email:
            domain = ['|', ('partner_id', '=', partner.id), ('email', '=ilike', user_email)]
        return domain

    def _can_access_registration(self, registration):
        if not registration:
            return False
        partner = request.env.user.partner_id
        user_email = (request.env.user.email or partner.email or '').strip().lower()
        reg_email = (registration.email or '').strip().lower()
        return registration.partner_id.id == partner.id or (user_email and reg_email == user_email)

    def _get_event_time_status(self, event, now_dt=None):
        now_dt = now_dt or fields.Datetime.now()
        stage_name = (event.stage_id.name or '').strip().lower()
        if stage_name == 'cancelled':
            return ('cancelled', 'Cancelled', 'bg-danger')
        if stage_name == 'ended':
            return ('past', 'Ended', 'bg-secondary')
        date_begin = event.date_begin
        date_end = event.date_end

        if date_end and date_end < now_dt:
            return ('past', 'Past', 'bg-danger')
        if date_begin and date_begin > now_dt:
            return ('upcoming', 'Upcoming', 'bg-success')
        return ('present', 'Present', 'bg-warning text-dark')

    def _get_registration_status(self, registration, now_dt=None):
        if registration.state == 'cancel':
            return ('cancelled', 'Cancelled', 'bg-danger')
        return self._get_event_time_status(registration.event_id, now_dt=now_dt)

    def _get_cancelled_refund_state(self, registrations):
        refundable_regs = registrations.filtered(lambda r: r.state == 'cancel')
        if not refundable_regs:
            return ('', '')
        if 'refund_processed' not in refundable_regs._fields:
            return ('not_refunded', 'Refund not tracked')
        refunded_regs = refundable_regs.filtered(lambda r: r.refund_processed)
        if refunded_regs and len(refunded_regs) == len(refundable_regs):
            return ('refunded', 'Refunded')
        if refunded_regs:
            return ('partial_refunded', 'Partially Refunded')
        return ('not_refunded', 'Not Refunded')

    def _event_allows_self_checkin(self, event):
        status_code, _, _ = self._get_event_time_status(event)
        return status_code in ('upcoming', 'present')

    def _registration_allows_self_checkin(self, registration):
        if registration.state == 'cancel':
            return False
        return self._event_allows_self_checkin(registration.event_id)

    def _get_ticket_status_display(self, status_code):
        if status_code == 'cancelled':
            return ('Cancelled', 'bg-danger')
        if status_code == 'past':
            return ('Ended', 'bg-secondary')
        return ('Active', 'bg-success')

    def _get_ticket_filter_group(self, status_code):
        if status_code == 'cancelled':
            return 'cancelled'
        if status_code == 'past':
            return 'ended'
        return 'active'

    def _matches_ticket_status_filter(self, status_code, status_filter):
        status_filter = (status_filter or 'active').strip().lower()
        ticket_group = self._get_ticket_filter_group(status_code)
        if status_filter == 'ended':
            return ticket_group == 'ended'
        if status_filter == 'cancelled':
            return ticket_group == 'cancelled'
        if status_filter == 'all':
            return True
        return ticket_group == 'active'


    def _get_point_balance(self):
        try:
            if 'event.points.wallet' not in request.env:
                return 0
            wallet = request.env['event.points.wallet'].get_or_create_wallet(request.env.user.partner_id)
            return int(wallet.balance or 0)
        except Exception:
            return 0

    def _get_event_notification_count(self):
        return request.env['event.application.notification'].sudo().search_count([
            ('partner_id', '=', request.env.user.partner_id.id),
            ('is_read', '=', False),
        ])

    def _parse_csv_int_ids(self, csv_value):
        ids = []
        for part in (csv_value or '').split(','):
            value = (part or '').strip()
            if value.isdigit():
                ids.append(int(value))
        return ids

    def _parse_custom_names(self, names_text):
        names = []
        seen = set()
        for raw_name in (names_text or '').replace('\n', ',').split(','):
            name = (raw_name or '').strip()
            if not name:
                continue
            lowered = name.lower()
            if lowered in seen:
                continue
            names.append(name)
            seen.add(lowered)
        return names

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if 'event_point_balance' in counters:
            values['event_point_balance'] = self._get_point_balance()
        if 'event_notification_count' in counters:
            values['event_notification_count'] = self._get_event_notification_count()
        if 'event_application_count' in counters:
            values['event_application_count'] = request.env['event.application'].search_count([
                ('partner_id', '=', request.env.user.partner_id.id)
            ])
        if 'my_events_count' in counters:
            values['my_events_count'] = request.env['event.event'].sudo().search_count(
                self._my_event_domain(
                    request.env.user.partner_id,
                    published_only=True,
                    stage_scope='live',
                )
            )
        return values
    
    @http.route(['/my/events', '/my/events/registrations'], type='http', auth='user', website=True)
    def my_events(self, **kwargs):
        """Show user's published events"""
        partner = request.env.user.partner_id
        path = request.httprequest.path or ''
        forced_tab = 'registrations' if path.rstrip('/').endswith('/my/events/registrations') else ''
        current_tab = (forced_tab or kwargs.get('tab') or 'events').strip().lower()
        if current_tab not in ('events', 'registrations'):
            current_tab = 'events'
        events_search = (kwargs.get('events_search') or '').strip()
        events_view = (kwargs.get('events_view') or 'upcoming').strip().lower()
        if events_view not in ('upcoming', 'past'):
            events_view = 'upcoming'
        registrations_search = (kwargs.get('registrations_search') or '').strip()
        registrations_status = (kwargs.get('registrations_status') or 'active').strip().lower()
        if registrations_status not in ('active', 'ended', 'cancelled', 'all'):
            registrations_status = 'active'

        now_dt = fields.Datetime.now()
        events_domain = self._my_event_domain(
            partner,
            published_only=True,
            stage_scope='past' if events_view == 'past' else 'live',
        )
        if events_search:
            events_domain += ['|', '|', ('name', 'ilike', events_search), ('location', 'ilike', events_search), ('address_id.name', 'ilike', events_search)]

        event_order = 'date_begin asc, id asc' if events_view != 'past' else 'date_begin desc, id desc'
        events = request.env['event.event'].sudo().search(events_domain, order=event_order)

        registrations_domain_base = list(self._registration_owner_domain())
        all_registrations = request.env['event.registration'].sudo().search(
            registrations_domain_base,
            order='create_date desc'
        )

        registrations_domain = list(registrations_domain_base)
        if registrations_search:
            registrations_domain += ['|', '|', ('name', 'ilike', registrations_search), ('email', 'ilike', registrations_search), ('event_id.name', 'ilike', registrations_search)]

        registrations = request.env['event.registration'].sudo().search(
            registrations_domain,
            order='create_date desc'
        )
        now_dt = fields.Datetime.now()
        batches_map = {}
        for reg in registrations:
            batch_id = reg.x_register_batch_id or f"single-{reg.id}"
            batches_map.setdefault(batch_id, request.env['event.registration'].sudo().browse())
            batches_map[batch_id] |= reg

        registration_batches = []
        for batch_id, regs in batches_map.items():
            first = regs[0]
            status_source = first
            cancelled_regs = regs.filtered(lambda r: r.state == 'cancel')
            if cancelled_regs:
                status_source = cancelled_regs[0]
            status_code, status_label, status_badge = self._get_registration_status(status_source, now_dt)
            ticket_status_label, ticket_status_badge = self._get_ticket_status_display(status_code)
            download_url = (
                f"/my/event-registrations/batch/{batch_id}/ticket"
                if not batch_id.startswith("single-")
                else f"/my/event-registration/{first.id}/ticket"
            )
            # Build ticket type summary (e.g., "First Class x2, Economy x1")
            type_counter = {}
            for reg in regs:
                type_name = reg.event_ticket_id.name or "Ticket"
                type_counter[type_name] = type_counter.get(type_name, 0) + 1
            ticket_type_labels = [f"{name} x{qty}" for name, qty in type_counter.items()]
            all_checked_in = all(r.state == 'done' for r in regs)
            self_checkin_allowed = all(self._registration_allows_self_checkin(reg) for reg in regs)
            registration_batches.append({
                "batch_id": batch_id,
                "event": first.event_id,
                "count": len(regs),
                "buyer_name": first.partner_id.name,
                "buyer_email": first.email,
                "buyer_phone": first.phone,
                "ticket_names": [r.name for r in regs],
                "ticket_types": ticket_type_labels,
                "download_url": download_url,
                "create_date": first.create_date,
                "status_code": status_code,
                "status_filter_group": self._get_ticket_filter_group(status_code),
                "status_label": status_label,
                "status_badge": status_badge,
                "ticket_status_label": ticket_status_label,
                "ticket_status_badge": ticket_status_badge,
                "refund_status_code": self._get_cancelled_refund_state(regs)[0],
                "refund_status_label": self._get_cancelled_refund_state(regs)[1],
                "can_download": status_code in ('upcoming', 'present'),
                "can_delete": status_code in ('past', 'cancelled'),
                "all_checked_in": all_checked_in,
                "self_checkin_allowed": self_checkin_allowed,
            })

        registration_batches = [
            batch for batch in registration_batches
            if self._matches_ticket_status_filter(batch.get("status_code"), registrations_status)
        ]
        registration_batches.sort(key=lambda b: b.get("create_date") or "", reverse=True)
        return request.render('event_application.portal_my_events', {
            'events': events,
            'registration_batches': registration_batches,
            'current_tab': current_tab,
            'current_datetime': now_dt,
            'events_search': events_search,
            'events_view': events_view,
            'registrations_search': registrations_search,
            'registrations_status': registrations_status,
            'registrations_filter_active': bool(registrations_search or registrations_status != 'active'),
            'event_notification_count': self._get_event_notification_count(),
        })

    @http.route(['/my/event-registrations'], type='http', auth='user', website=True)
    def my_event_registrations_index(self, **kwargs):
        """List registrations for the current portal user"""
        search = (kwargs.get('search') or '').strip()
        status_filter = (kwargs.get('status') or 'active').strip().lower()
        if status_filter not in ('active', 'ended', 'cancelled', 'all'):
            status_filter = 'active'
        base_domain = list(self._registration_owner_domain())
        all_registrations = request.env['event.registration'].sudo().search(base_domain, order='create_date desc')

        domain = list(base_domain)
        if search:
            domain += ['|', '|', ('name', 'ilike', search), ('email', 'ilike', search), ('event_id.name', 'ilike', search)]

        registrations = request.env['event.registration'].sudo().search(domain, order='create_date desc')
        now_dt = fields.Datetime.now()
        batches_map = {}
        for reg in registrations:
            batch_id = reg.x_register_batch_id or f"single-{reg.id}"
            batches_map.setdefault(batch_id, request.env['event.registration'].sudo().browse())
            batches_map[batch_id] |= reg

        registration_batches = []
        for batch_id, regs in batches_map.items():
            first = regs[0]
            status_source = first
            cancelled_regs = regs.filtered(lambda r: r.state == 'cancel')
            if cancelled_regs:
                status_source = cancelled_regs[0]
            status_code, status_label, status_badge = self._get_registration_status(status_source, now_dt)
            ticket_status_label, ticket_status_badge = self._get_ticket_status_display(status_code)
            download_url = (
                f"/my/event-registrations/batch/{batch_id}/ticket"
                if not batch_id.startswith("single-")
                else f"/my/event-registration/{first.id}/ticket"
            )
            type_counter = {}
            for reg in regs:
                type_name = reg.event_ticket_id.name or "Ticket"
                type_counter[type_name] = type_counter.get(type_name, 0) + 1
            ticket_type_labels = [f"{name} x{qty}" for name, qty in type_counter.items()]
            all_checked_in = all(r.state == 'done' for r in regs)
            self_checkin_allowed = all(self._registration_allows_self_checkin(reg) for reg in regs)
            registration_batches.append({
                "batch_id": batch_id,
                "event": first.event_id,
                "count": len(regs),
                "buyer_name": first.partner_id.name,
                "buyer_email": first.email,
                "buyer_phone": first.phone,
                "ticket_names": [r.name for r in regs],
                "ticket_types": ticket_type_labels,
                "download_url": download_url,
                "create_date": first.create_date,
                "status_code": status_code,
                "status_filter_group": self._get_ticket_filter_group(status_code),
                "status_label": status_label,
                "status_badge": status_badge,
                "ticket_status_label": ticket_status_label,
                "ticket_status_badge": ticket_status_badge,
                "refund_status_code": self._get_cancelled_refund_state(regs)[0],
                "refund_status_label": self._get_cancelled_refund_state(regs)[1],
                "can_download": status_code in ('upcoming', 'present'),
                "can_delete": status_code in ('past', 'cancelled'),
                "all_checked_in": all_checked_in,
                "self_checkin_allowed": self_checkin_allowed,
            })

        registration_batches = [
            batch for batch in registration_batches
            if self._matches_ticket_status_filter(batch.get("status_code"), status_filter)
        ]
        registration_batches.sort(key=lambda b: b.get("create_date") or "", reverse=True)

        return request.render('event_application.portal_my_event_registration_index', {
            'registration_batches': registration_batches,
            'search': search,
            'status_filter': status_filter,
            'filter_active': bool(search or status_filter != 'active'),
        })

    @http.route(['/my/event-registration/<int:registration_id>'], type='http', auth='user', website=True)
    def my_event_registration_detail(self, registration_id, **kwargs):
        """Show QR for a single registration"""
        registration = request.env['event.registration'].sudo().browse(registration_id)
        if not registration or not self._can_access_registration(registration):
            return request.redirect('/my/event-registrations')
        checkin_base = request.httprequest.url_root.rstrip('/')
        registration_status = self._get_registration_status(registration)
        ticket_status_label, ticket_status_badge = self._get_ticket_status_display(registration_status[0])
        return request.render('event_application.portal_my_event_registration_detail', {
            'registration': registration,
            'event': registration.event_id,
            'checkin_base': checkin_base,
            'quote_plus': quote_plus,
            'registration_status': registration_status,
            'ticket_status_label': ticket_status_label,
            'ticket_status_badge': ticket_status_badge,
            'refund_status': self._get_cancelled_refund_state(registration),
            'can_download': registration_status[0] in ('upcoming', 'present'),
            'can_delete': registration_status[0] in ('past', 'cancelled'),
            'self_checkin_allowed': self._registration_allows_self_checkin(registration),
        })

    @http.route(
        ['/my/event-registration/<int:registration_id>/delete'],
        type='http',
        auth='user',
        website=True,
        methods=['POST'],
        csrf=True,
    )
    def delete_my_event_registration(self, registration_id, **post):
        registration = request.env['event.registration'].sudo().browse(registration_id)
        if not registration.exists() or not self._can_access_registration(registration):
            return request.redirect('/my/event-registrations')
        status_code = self._get_registration_status(registration)[0]
        if status_code not in ('past', 'cancelled'):
            return request.redirect('/my/event-registration/%s' % registration_id)
        registration.unlink()
        return request.redirect('/my/event-registrations?deleted=1')

    @http.route(
        ['/my/event-registrations/batch/<string:batch_id>/delete'],
        type='http',
        auth='user',
        website=True,
        methods=['POST'],
        csrf=True,
    )
    def delete_my_event_registration_batch(self, batch_id, **post):
        domain = self._registration_owner_domain()
        registrations = request.env['event.registration'].sudo().search(
            [('x_register_batch_id', '=', batch_id)] + domain
        )
        if not registrations and batch_id.startswith('single-'):
            try:
                reg_id = int(batch_id.split('-', 1)[1])
            except (IndexError, ValueError):
                reg_id = False
            if reg_id:
                candidate = request.env['event.registration'].sudo().browse(reg_id)
                if candidate.exists() and self._can_access_registration(candidate):
                    registrations = candidate
        if not registrations:
            return request.redirect('/my/event-registrations')
        batch_status_code = self._get_registration_status(
            registrations.filtered(lambda reg: reg.state == 'cancel')[:1] or registrations[:1]
        )[0]
        if batch_status_code not in ('past', 'cancelled'):
            return request.redirect('/my/event-registrations')
        registrations.unlink()
        return request.redirect('/my/event-registrations?deleted=1')

    @http.route(
        ['/my/event-registrations/batch/<string:batch_id>/self-checkin'],
        type='json',
        auth='user',
        website=True,
        csrf=False,
    )
    def my_event_registration_self_checkin(self, batch_id, **kwargs):
        """Allow portal users to self-check-in their own tickets for a batch."""
        domain = self._registration_owner_domain()
        regs = request.env['event.registration'].sudo().search(
            [('x_register_batch_id', '=', batch_id)] + domain
        )

        if not regs and batch_id.startswith("single-"):
            try:
                reg_id = int(batch_id.split("-", 1)[1])
            except (IndexError, ValueError):
                reg_id = False
            if reg_id:
                candidate = request.env['event.registration'].sudo().browse(reg_id)
                if candidate.exists() and self._can_access_registration(candidate):
                    regs = candidate

        if not regs:
            return {"ok": False, "message": "Ticket not found or not accessible."}

        if not all(self._registration_allows_self_checkin(reg) for reg in regs):
            return {"ok": False, "status": "cancelled", "message": "This event has been cancelled. Self check-in is unavailable."}

        to_mark = regs.filtered(lambda r: r.state != "done")
        if to_mark:
            to_mark.action_mark_attended()

        status = "checked_in" if to_mark else "already_checked_in"
        return {
            "ok": True,
            "marked": len(to_mark),
            "total": len(regs),
            "all_checked_in": all(r.state == "done" for r in regs),
            "status": status,
        }
    
    @http.route(['/my/event/<int:event_id>'], type='http', auth='user', website=True)
    def my_event_detail(self, event_id, **kwargs):
        """Show event details for editing"""
        event = request.env['event.event'].sudo().browse(event_id)
        if not event.exists():
            return request.redirect('/my')

        is_admin = request.env.user.has_group('base.group_system')
        is_owner = event.organizer_id.id == request.env.user.partner_id.id
        if not is_admin and not is_owner:
            return request.redirect('/my')

        specialties = request.env['event.specialty'].sudo().search([])
        cases = request.env['event.case'].sudo().search([])
        countries = request.env['res.country'].sudo().search([], order='name')
        states = request.env['res.country.state'].sudo().search([], order='country_id, name')
        ticket_fields = request.env['event.event.ticket']._fields

        return request.render('event_application.portal_my_event_detail', {
            'event': event,
            'specialties': specialties,
            'cases': cases,
            'countries': countries,
            'states': states,
            'is_admin': is_admin,
            'can_edit_tickets': is_admin,
            'allow_ticket_point_cost': 'point_cost' in ticket_fields,
        })
    
    @http.route(['/my/event/<int:event_id>/update'], type='http', auth='user', website=True, methods=['POST'], csrf=True)
    def my_event_update(self, event_id, **post):
        """Update event details"""
        event = request.env['event.event'].sudo().browse(event_id)

        if not event.exists():
            return request.redirect('/my')

        is_admin = request.env.user.has_group('base.group_system')
        is_owner = event.organizer_id.id == request.env.user.partner_id.id
        if not is_admin and not is_owner:
            return request.redirect('/my')

        update_vals = {}

        posted_name = (post.get('name') or '').strip()
        if posted_name:
            update_vals['name'] = posted_name

        if 'description' in post:
            update_vals['description'] = post.get('description')

        if 'location' in post:
            update_vals['location'] = post.get('location')

        if post.get('seats_max') not in (None, ''):
            update_vals['seats_max'] = int(post.get('seats_max'))

        if post.get('date_begin'):
            parsed = self._convert_datetime(post.get('date_begin'))
            if parsed:
                update_vals['date_begin'] = parsed

        if post.get('date_end'):
            parsed = self._convert_datetime(post.get('date_end'))
            if parsed:
                update_vals['date_end'] = parsed

        specialty_ids = request.httprequest.form.getlist('specialty_ids')
        if specialty_ids:
            update_vals['specialty_ids'] = [(6, 0, [int(sid) for sid in specialty_ids])]
        else:
            update_vals['specialty_ids'] = [(5, 0, 0)]
        if 'specialty_other_names' in post and 'specialty_other_text' in event._fields:
            specialty_other_names = self._parse_custom_names(post.get('specialty_other_names'))
            update_vals['specialty_other_text'] = ', '.join(specialty_other_names) if specialty_other_names else False

        case_ids = request.httprequest.form.getlist('case_ids')
        if case_ids:
            update_vals['case_ids'] = [(6, 0, [int(cid) for cid in case_ids])]
        else:
            update_vals['case_ids'] = [(5, 0, 0)]
        if 'case_other_names' in post and 'case_other_text' in event._fields:
            case_other_names = self._parse_custom_names(post.get('case_other_names'))
            update_vals['case_other_text'] = ', '.join(case_other_names) if case_other_names else False

        if is_admin:
            for field_name in (
                'contact_phone',
                'contact_email',
                'venue_name',
                'building_name',
                'street_address',
                'street_address2',
                'district',
                'floor',
                'unit_no',
                'city',
                'zip_code',
                'online_platform',
                'online_link',
                'address_input',
            ):
                if field_name in post:
                    update_vals[field_name] = post.get(field_name) or False
            if 'online_link' in update_vals:
                update_vals['online_link'] = self._normalize_online_link(update_vals['online_link'])

            if 'venue_type' in post:
                update_vals['venue_type'] = post.get('venue_type') or 'physical'
            if post.get('state_id'):
                update_vals['state_id'] = int(post.get('state_id'))
            elif 'state_id' in post:
                update_vals['state_id'] = False
            if post.get('country_id'):
                update_vals['country_id'] = int(post.get('country_id'))
            elif 'country_id' in post:
                update_vals['country_id'] = False

            ticket_model = request.env['event.event.ticket'].sudo()
            ticket_fields = ticket_model._fields
            for ticket in event.event_ticket_ids.sorted(lambda t: ((not t.is_pinned), t.sequence, t.id)):
                tvals = {}
                name_key = f'ticket_name_{ticket.id}'
                if name_key in post:
                    tvals['name'] = post.get(name_key) or ticket.name

                start_key = f'ticket_start_{ticket.id}'
                if start_key in post and 'start_sale_datetime' in ticket_fields:
                    tvals['start_sale_datetime'] = self._convert_datetime(post.get(start_key)) if post.get(start_key) else False

                end_key = f'ticket_end_{ticket.id}'
                if end_key in post and 'end_sale_datetime' in ticket_fields:
                    tvals['end_sale_datetime'] = self._convert_datetime(post.get(end_key)) if post.get(end_key) else False

                limit_key = f'ticket_limit_{ticket.id}'
                if limit_key in post and 'seats_limited' in ticket_fields:
                    tvals['seats_limited'] = str(post.get(limit_key)) == '1'

                max_key = f'ticket_max_{ticket.id}'
                if max_key in post and 'seats_max' in ticket_fields:
                    tvals['seats_max'] = int(post.get(max_key)) if post.get(max_key) else 0

                points_key = f'ticket_point_cost_{ticket.id}'
                if points_key in post and 'point_cost' in ticket_fields:
                    tvals['point_cost'] = int(post.get(points_key)) if post.get(points_key) else 0

                if tvals:
                    ticket.write(tvals)

        # Update both base and current UI language values to avoid stale
        # translated titles showing the previous event name.
        if 'name' in update_vals:
            new_name = update_vals.pop('name')
            event.with_context(lang=False).write({'name': new_name})
            lang_code = request.env.context.get('lang')
            if lang_code:
                event.with_context(lang=lang_code).write({'name': new_name})
            application = event.application_id.sudo() or request.env['event.application'].sudo().search([('event_id', '=', event.id)], limit=1)
            if application:
                application.write({'name': new_name})

        if update_vals:
            event.write(update_vals)

        return request.redirect(f'/my/event/{event_id}?success=1')
    
    @http.route(['/my/event/applications'], type='http', auth='user', website=True)
    def my_applications(self, **kwargs):
        applications = request.env['event.application'].search([
            ('partner_id', '=', request.env.user.partner_id.id)
        ])
        return request.render('event_application.portal_my_applications', {
            'applications': applications,
            'event_notification_count': self._get_event_notification_count(),
        })

    @http.route(['/my/event/application/<int:application_id>/delete'], type='http', auth='user', website=True, methods=['POST'], csrf=True)
    def event_application_delete(self, application_id, **kwargs):
        application = request.env['event.application'].sudo().browse(application_id)
        if not application.exists() or application.partner_id.id != request.env.user.partner_id.id:
            return request.redirect('/my/event/applications')
        if application.state != 'draft':
            return request.redirect('/my/event/applications')
        application.unlink()
        return request.redirect('/my/event/applications')
    
    @http.route(['/event/apply'], type='http', auth='user', website=True)
    def event_application_form(self, **kwargs):
        # Get all available specialties and cases for selection
        specialties = request.env['event.specialty'].search([])
        cases = request.env['event.case'].search([])
        
        # Get countries and states for address dropdowns
        countries = request.env['res.country'].search([], order='name')
        states = request.env['res.country.state'].search([], order='country_id, name')
        
        return request.render('event_application.event_application_form', {
            'specialties': specialties,
            'cases': cases,
            'countries': countries,
            'states': states,
            'form_error': kwargs.get('error'),
        })
    
    def _convert_datetime(self, date_str):
        """Convert datetime-local format to Odoo format"""
        if not date_str:
            return False
        try:
            dt = datetime.strptime(date_str, '%Y-%m-%dT%H:%M')
        except (ValueError, TypeError):
            return False
        tz_name = (
            request.env.context.get('tz')
            or request.env.user.tz
            or request.env.company.partner_id.tz
            or 'UTC'
        )
        try:
            tzinfo = pytz.timezone(tz_name)
        except pytz.UnknownTimeZoneError:
            tzinfo = pytz.UTC
        dt_local = tzinfo.localize(dt, is_dst=None)
        dt_utc = dt_local.astimezone(pytz.UTC)
        return fields.Datetime.to_string(dt_utc)

    def _format_datetime_local(self, dt):
        """Convert stored datetime to datetime-local string in user's TZ."""
        if not dt:
            return ''
        try:
            dt_utc = fields.Datetime.to_datetime(dt)
        except Exception:
            return ''
        tz_name = (
            request.env.context.get('tz')
            or request.env.user.tz
            or request.env.company.partner_id.tz
            or 'UTC'
        )
        try:
            tzinfo = pytz.timezone(tz_name)
        except pytz.UnknownTimeZoneError:
            tzinfo = pytz.UTC
        dt_local = dt_utc.astimezone(tzinfo)
        return dt_local.replace(tzinfo=None).strftime('%Y-%m-%dT%H:%M')

    def _build_draft_from_application(self, application):
        """Map an existing application into the form draft payload (sessionStorage)."""
        fmt = self._format_datetime_local
        payload = {
            'event_name': application.name or '',
            'partner_id': request.env.user.partner_id.id,
            'date_begin': fmt(application.date_begin),
            'date_end': fmt(application.date_end),
            'registration_start': fmt(application.registration_start),
            'registration_end': fmt(application.registration_end),
            'registration_limit': '1' if application.registration_limit else '0',
            'max_registrations': str(application.max_registrations or 0),
            'venue_type': application.venue_type or 'physical',
            'online_platform': application.online_platform or '',
            'online_link': application.online_link or '',
            'venue_name': application.venue_name or '',
            'building_name': application.building_name or '',
            'address_input': application.address_input or '',
            'street_address': application.street_address or '',
            'street_address2': application.street_address2 or '',
            'district': application.district or '',
            'floor': application.floor or '',
            'unit_no': application.unit_no or '',
            'city': application.city or '',
            'zip_code': application.zip_code or '',
            'state_id': application.state_id.id or '',
            'country_id': application.country_id.id or '',
            'contact_phone': application.contact_phone or '',
            'contact_email': application.contact_email or '',
            'description': html2plaintext(application.description or '') if application.description else '',
            'specialty_ids': ','.join(str(i) for i in application.specialty_ids.ids),
            'specialty_other_names': application.specialty_other_text or '',
            'case_ids': ','.join(str(i) for i in application.case_ids.ids),
            'case_other_names': application.case_other_text or '',
            'thumbnail_choice': '0',
            'resubmit_application_id': application.id,
            'submission_point_cost': application.submission_point_cost or self._get_submission_point_cost(),
            'existing_image_ids': ','.join(str(i) for i in application.image_ids.ids),
            'badge_image_url': application.badge_image and f"/web/image/event.application/{application.id}/badge_image/720x0" or '',
            'badge_image_b64': (
                application.badge_image.decode('ascii')
                if isinstance(application.badge_image, (bytes, bytearray))
                else (application.badge_image or '')
            ),
            'thumbnail_choice': '0',
            'thumbnail_image_url': application.thumbnail_image and f"/web/image/event.application/{application.id}/thumbnail_image/720x0" or '',
            'specialty_id_list': application.specialty_ids.ids,
            'case_id_list': application.case_ids.ids,
        }
        ticket_lines = application.ticket_line_ids.sorted('sequence') if application.ticket_line_ids else []
        payload['ticket_name[]'] = [line.name or '' for line in ticket_lines]
        payload['ticket_start[]'] = [fmt(line.start_sale_datetime) for line in ticket_lines]
        payload['ticket_end[]'] = [fmt(line.end_sale_datetime) for line in ticket_lines]
        payload['ticket_limit[]'] = ['1' if line.seats_limited else '0' for line in ticket_lines]
        payload['ticket_max[]'] = [str(line.seats_max or '') for line in ticket_lines]
        payload['ticket_points[]'] = [str(line.point_cost or 0) for line in ticket_lines]
        return payload

    def _application_payment_session_key(self):
        return 'event_application_submit_payment'

    def _get_submission_point_cost(self):
        raw_value = request.env['ir.config_parameter'].sudo().get_param(
            'event_application.submission_point_cost',
            default='75',
        )
        try:
            return max(int(raw_value or 0), 0)
        except (TypeError, ValueError):
            return 75

    def _get_points_wallet(self):
        if 'event.points.wallet' not in request.env:
            return False
        try:
            return request.env['event.points.wallet'].get_or_create_wallet(request.env.user.partner_id)
        except Exception:
            return False

    def _build_application_payload(self, post):
        date_begin = self._convert_datetime(post.get('date_begin'))
        date_end = self._convert_datetime(post.get('date_end'))
        registration_start = self._convert_datetime(post.get('registration_start'))
        registration_end = self._convert_datetime(post.get('registration_end'))
        registration_limit = bool(post.get('registration_limit'))
        max_registrations = int(post.get('max_registrations')) if post.get('max_registrations') else 0

        if not date_begin or not date_end:
            return None, 'invalid_dates'
        if date_begin and date_end and date_begin > date_end:
            return None, 'invalid_date_range'
        if registration_start and registration_end and registration_start > registration_end:
            return None, 'invalid_registration_dates'

        form_data = request.httprequest.form
        ticket_names = form_data.getlist('ticket_name[]')
        ticket_starts = form_data.getlist('ticket_start[]')
        ticket_ends = form_data.getlist('ticket_end[]')
        ticket_limits = form_data.getlist('ticket_limit[]')
        ticket_maxes = form_data.getlist('ticket_max[]')
        ticket_points = form_data.getlist('ticket_points[]')

        row_count = max(
            len(ticket_names),
            len(ticket_starts),
            len(ticket_ends),
            len(ticket_limits),
            len(ticket_maxes),
            len(ticket_points),
        )
        ticket_lines = []
        for idx in range(row_count):
            raw_name = (ticket_names[idx] if idx < len(ticket_names) else '').strip()
            raw_start = ticket_starts[idx] if idx < len(ticket_starts) else ''
            raw_end = ticket_ends[idx] if idx < len(ticket_ends) else ''
            raw_limit = ticket_limits[idx] if idx < len(ticket_limits) else '0'
            raw_max = ticket_maxes[idx] if idx < len(ticket_maxes) else ''
            raw_points = (ticket_points[idx] if idx < len(ticket_points) else '').strip()

            has_points = bool(raw_points) and raw_points != '0'
            if not any([raw_name, raw_start, raw_end, raw_max, has_points]):
                continue
            if not raw_name:
                return None, 'ticket_name_required'

            start_dt = self._convert_datetime(raw_start)
            end_dt = self._convert_datetime(raw_end)
            if raw_start and not start_dt:
                return None, 'invalid_ticket_dates'
            if raw_end and not end_dt:
                return None, 'invalid_ticket_dates'
            if start_dt and end_dt and start_dt > end_dt:
                return None, 'invalid_ticket_date_range'

            seats_limited = str(raw_limit) == '1'
            seats_max = int(raw_max) if raw_max else 0
            if seats_limited and seats_max <= 0:
                return None, 'invalid_ticket_max'

            point_cost = int(raw_points) if raw_points else 0
            if point_cost < 0:
                return None, 'invalid_ticket_points'

            ticket_lines.append({
                'name': raw_name,
                'start_sale_datetime': start_dt,
                'end_sale_datetime': end_dt,
                'seats_limited': seats_limited,
                'seats_max': seats_max if seats_limited else 0,
                'point_cost': point_cost,
                'sequence': (idx + 1) * 10,
            })
        # Deduplicate ticket lines (prevents duplicates on repeated edit/resubmit)
        seen_ticket_keys = set()
        unique_ticket_lines = []
        for line in ticket_lines:
            key = (
                line['name'],
                line['start_sale_datetime'],
                line['end_sale_datetime'],
                line['seats_limited'],
                line['seats_max'],
                line['point_cost'],
            )
            if key in seen_ticket_keys:
                continue
            seen_ticket_keys.add(key)
            unique_ticket_lines.append(line)
        ticket_lines = unique_ticket_lines

        specialty_ids = self._parse_csv_int_ids(post.get('specialty_ids', ''))
        specialty_ids = list(dict.fromkeys(specialty_ids))
        specialty_other_names = self._parse_custom_names(post.get('specialty_other_names'))

        case_ids = self._parse_csv_int_ids(post.get('case_ids', ''))
        case_ids = list(dict.fromkeys(case_ids))
        case_other_names = self._parse_custom_names(post.get('case_other_names'))

        max_upload_bytes = 2 * 1024 * 1024  # 2 MB per image

        def _bin_to_b64(val):
            """Return a base64 string from raw bytes/memoryview or existing base64 bytes."""
            if isinstance(val, memoryview):
                val = val.tobytes()
            if isinstance(val, bytes):
                try:
                    # most Odoo image fields already store base64 in bytes
                    return val.decode('ascii')
                except Exception:
                    return base64.b64encode(val).decode('ascii')
            return val

        badge_image = False
        badge_file = request.httprequest.files.get('badge_image')
        if badge_file and badge_file.filename:
            badge_bytes = badge_file.read()
            if badge_bytes and len(badge_bytes) > max_upload_bytes:
                return None, 'image_too_large'
            badge_image = base64.b64encode(badge_bytes).decode('ascii') if badge_bytes else False
        badge_image = _bin_to_b64(badge_image)
        if not badge_image:
            badge_image = _bin_to_b64(post.get('existing_badge_image'))

        card_bg_image = False

        # Multiple event images + thumbnail selection
        gallery_images = []
        thumbnail_image = False
        raw_thumbnail_choice = (post.get('thumbnail_choice') or '').strip()
        try:
            thumbnail_choice_idx = int(raw_thumbnail_choice)
        except (TypeError, ValueError):
            thumbnail_choice_idx = 0

        resubmit_id = int(post.get('resubmit_application_id') or 0)
        existing_ids = self._parse_csv_int_ids(post.get('existing_image_ids', ''))
        image_files = request.httprequest.files.getlist('event_images') or []
        for idx, upload in enumerate(image_files):
            if not upload or not upload.filename:
                continue
            image_bytes = upload.read()
            if image_bytes and len(image_bytes) > max_upload_bytes:
                return None, 'image_too_large'
            image_data = base64.b64encode(image_bytes).decode('ascii') if image_bytes else False
            if image_data:
                gallery_images.append({
                    'name': upload.filename or f"Image {idx + 1}",
                    'image': image_data,
                    'sequence': (idx + 1) * 10,
                })
                if thumbnail_image is False and idx == thumbnail_choice_idx:
                    thumbnail_image = image_data
        if thumbnail_image is False and gallery_images:
            # Default to the first uploaded image when no explicit choice
            thumbnail_image = gallery_images[0]['image']
        # Reuse gallery from previous application or explicit selection when no new uploads
        if not gallery_images:
            if existing_ids:
                for idx, img in enumerate(request.env['event.application.image'].sudo().browse(existing_ids)):
                    if not img.image:
                        continue
                    img_data = _bin_to_b64(img.image)
                    gallery_images.append({
                        'name': img.name or f"Image {idx + 1}",
                        'image': img_data,
                        'sequence': (idx + 1) * 10,
                    })
                if gallery_images and thumbnail_image is False:
                    thumbnail_image = gallery_images[0]['image']
            elif resubmit_id:
                existing_app = request.env['event.application'].sudo().browse(resubmit_id)
                if existing_app.exists() and existing_app.partner_id.id == request.env.user.partner_id.id:
                    for idx, img in enumerate(existing_app.image_ids.sorted('sequence')):
                        if not img.image:
                            continue
                        img_data = _bin_to_b64(img.image)
                        gallery_images.append({
                            'name': img.name or f"Image {idx + 1}",
                            'image': img_data,
                            'sequence': (idx + 1) * 10,
                        })
                    if gallery_images and thumbnail_image is False:
                        thumbnail_image = gallery_images[0]['image']
        # Deduplicate gallery images to avoid duplicates on repeated resubmits
        deduped_gallery = []
        seen_gallery_keys = set()
        for img in gallery_images:
            key = (img.get('image'), img.get('name'))
            if key in seen_gallery_keys:
                continue
            seen_gallery_keys.add(key)
            deduped_gallery.append(img)
        gallery_images = deduped_gallery
        # Reuse badge when resubmitting if none uploaded
        if not badge_image and resubmit_id:
            existing_app = request.env['event.application'].sudo().browse(resubmit_id)
            if existing_app.exists() and existing_app.partner_id.id == request.env.user.partner_id.id:
                existing_badge = existing_app.badge_image
                if existing_badge:
                    badge_image = existing_badge if isinstance(existing_badge, str) else base64.b64encode(existing_badge).decode('ascii')
                    badge_image = _bin_to_b64(badge_image)
        if not badge_image:
            return None, 'badge_required'

        venue_type = post.get('venue_type', 'physical')
        country_id = int(post.get('country_id')) if post.get('country_id') else False
        state_id = int(post.get('state_id')) if post.get('state_id') else False
        zip_code = self._normalize_text_value(post.get('zip_code'))

        if venue_type == 'online':
            country_id = False
            state_id = False
            zip_code = False
        elif not self._validate_zip_code(country_id, zip_code):
            return None, 'invalid_zip_code'

        payload = {
            'name': self._normalize_text_value(post.get('event_name')),
            'partner_id': request.env.user.partner_id.id,
            'resubmit_application_id': resubmit_id or False,
            'date_begin': date_begin,
            'date_end': date_end,
            'registration_start': registration_start,
            'registration_end': registration_end,
            'registration_limit': registration_limit,
            'max_registrations': max_registrations if registration_limit else 0,
            'contact_phone': self._normalize_text_value(post.get('contact_phone')),
            'contact_email': self._normalize_text_value(post.get('contact_email')),
            'description': post.get('description'),
            'venue_type': venue_type,
            'online_platform': self._normalize_text_value(post.get('online_platform')) if venue_type == 'online' else False,
            'online_link': self._normalize_online_link(post.get('online_link')),
            'venue_name': self._normalize_text_value(post.get('venue_name')) if venue_type == 'physical' else False,
            'building_name': self._normalize_text_value(post.get('building_name')) if venue_type == 'physical' else False,
            'address_input': self._normalize_text_value(post.get('address_input')) if venue_type == 'physical' else False,
            'street_address': self._normalize_text_value(post.get('street_address')) if venue_type == 'physical' else False,
            'street_address2': self._normalize_text_value(post.get('street_address2')) if venue_type == 'physical' else False,
            'district': self._normalize_text_value(post.get('district')) if venue_type == 'physical' else False,
            'floor': self._normalize_text_value(post.get('floor')) if venue_type == 'physical' else False,
            'unit_no': self._normalize_text_value(post.get('unit_no')) if venue_type == 'physical' else False,
            'city': self._normalize_text_value(post.get('city')) if venue_type == 'physical' else False,
            'zip_code': zip_code,
            'state_id': state_id,
            'country_id': country_id,
            'specialty_ids': specialty_ids,
            'case_ids': case_ids,
            'specialty_other_text': ', '.join(specialty_other_names),
            'case_other_text': ', '.join(case_other_names),
            'ticket_lines': ticket_lines,
            'badge_image': badge_image,
            'card_bg_image': card_bg_image,
            'submission_point_cost': self._get_submission_point_cost(),
            'thumbnail_image': thumbnail_image,
            'gallery_images': gallery_images,
        }
        # Friendly URLs for previews (used in edit/resubmit flows)
        if resubmit_id:
            existing_app_urls = request.env['event.application'].sudo().browse(resubmit_id)
            payload['badge_image_url'] = existing_app_urls.badge_image and f"/web/image/event.application/{resubmit_id}/badge_image/720x0" or ''
            payload['thumbnail_image_url'] = existing_app_urls.thumbnail_image and f"/web/image/event.application/{resubmit_id}/thumbnail_image/720x0" or ''
        else:
            # fallback to data URIs when freshly uploaded
            if badge_image:
                payload['badge_image_url'] = f"data:image/png;base64,{badge_image}"
            if thumbnail_image:
                payload['thumbnail_image_url'] = f"data:image/png;base64,{thumbnail_image}"
        return payload, None

    def _build_application_vals_from_payload(self, payload):
        vals = {
            'name': payload.get('name'),
            'partner_id': payload.get('partner_id'),
            'date_begin': payload.get('date_begin'),
            'date_end': payload.get('date_end'),
            'registration_start': payload.get('registration_start'),
            'registration_end': payload.get('registration_end'),
            'registration_limit': payload.get('registration_limit'),
            'max_registrations': payload.get('max_registrations') or 0,
            'contact_phone': payload.get('contact_phone'),
            'contact_email': payload.get('contact_email'),
            'description': payload.get('description'),
            'venue_type': payload.get('venue_type', 'physical'),
            'state': 'draft',
            'submission_point_cost': payload.get('submission_point_cost') or 0,
        }
        if payload.get('venue_type') == 'online':
            vals.update({
                'online_platform': payload.get('online_platform'),
                'online_link': payload.get('online_link'),
            })
        else:
            vals.update({
                'venue_name': payload.get('venue_name'),
                'building_name': payload.get('building_name'),
                'address_input': payload.get('address_input'),
                'street_address': payload.get('street_address'),
                'street_address2': payload.get('street_address2'),
                'district': payload.get('district'),
                'floor': payload.get('floor'),
                'unit_no': payload.get('unit_no'),
                'city': payload.get('city'),
                'zip_code': payload.get('zip_code'),
                'state_id': payload.get('state_id') or False,
                'country_id': payload.get('country_id') or False,
            })

        specialty_ids = payload.get('specialty_ids') or []
        if specialty_ids:
            vals['specialty_ids'] = [(6, 0, specialty_ids)]
        case_ids = payload.get('case_ids') or []
        if case_ids:
            vals['case_ids'] = [(6, 0, case_ids)]
        vals['specialty_other_text'] = payload.get('specialty_other_text') or False
        vals['case_other_text'] = payload.get('case_other_text') or False

        ticket_lines = payload.get('ticket_lines') or []
        if ticket_lines:
            # Always replace the previous ticket set so resubmits don't keep old rows
            vals['ticket_line_ids'] = [(5, 0, 0)] + [(0, 0, line) for line in ticket_lines]

        def _clean_image(val):
            """Normalize image value to pure base64 string or return False."""
            if not val:
                return False
            if isinstance(val, bytes):
                val = base64.b64encode(val).decode('ascii')
            if isinstance(val, str) and val.startswith('data:'):
                # strip data URI prefix
                parts = val.split(',', 1)
                val = parts[1] if len(parts) > 1 else ''
            try:
                base64.b64decode(val, validate=True)
                return val
            except Exception:
                try:
                    base64.b64decode(val)
                    return val
                except Exception:
                    return False

        if _clean_image(payload.get('badge_image')):
            vals['badge_image'] = _clean_image(payload.get('badge_image'))
        elif payload.get('resubmit_application_id'):
            existing_app = request.env['event.application'].sudo().browse(payload.get('resubmit_application_id'))
            if existing_app.exists() and existing_app.badge_image:
                vals['badge_image'] = existing_app.badge_image
        if _clean_image(payload.get('thumbnail_image')):
            vals['thumbnail_image'] = _clean_image(payload.get('thumbnail_image'))
        gallery_images = []
        for img_vals in payload.get('gallery_images') or []:
            if not isinstance(img_vals, dict):
                continue
            img_copy = dict(img_vals)
            img_copy['image'] = _clean_image(img_copy.get('image'))
            if img_copy['image']:
                gallery_images.append(img_copy)
        if gallery_images:
            # Replace all existing gallery images when a new selection is provided
            vals['image_ids'] = [(5, 0, 0)] + [(0, 0, img_vals) for img_vals in gallery_images]
        # Final guard: if badge still missing on resubmit, copy from source application
        if not vals.get('badge_image') and payload.get('resubmit_application_id'):
            existing_app = request.env['event.application'].sudo().browse(payload.get('resubmit_application_id'))
            if existing_app.exists() and existing_app.badge_image:
                vals['badge_image'] = existing_app.badge_image
        return vals

    def _sanitize_payload_for_session(self, payload):
        """Ensure payload is JSON-serializable (no raw bytes)."""
        clean = dict(payload or {})
        def _to_iso(val):
            from datetime import date, datetime
            if isinstance(val, (datetime, date)):
                return val.isoformat()
            return val
        def _to_b64(val):
            if isinstance(val, bytes):
                val = base64.b64encode(val).decode('ascii')
            if isinstance(val, str) and val.startswith('data:'):
                parts = val.split(',', 1)
                val = parts[1] if len(parts) > 1 else ''
            try:
                base64.b64decode(val or '', validate=True)
                return val
            except Exception:
                try:
                    # accept lenient padding
                    base64.b64decode(val or '')
                    return val
                except Exception:
                    return False
        # datetime fields
        for key in ('date_begin', 'date_end', 'registration_start', 'registration_end'):
            clean[key] = _to_iso(clean.get(key))
        # Single images
        clean['badge_image'] = _to_b64(clean.get('badge_image'))
        clean['thumbnail_image'] = _to_b64(clean.get('thumbnail_image'))
        # If badge missing but coming from an existing application, pull from DB as fallback
        resubmit_id = clean.get('resubmit_application_id') or False
        if resubmit_id and not clean.get('badge_image'):
            existing_app = request.env['event.application'].sudo().browse(resubmit_id)
            if existing_app.exists() and existing_app.badge_image:
                val = existing_app.badge_image if isinstance(existing_app.badge_image, str) else base64.b64encode(existing_app.badge_image).decode('ascii')
                clean['badge_image'] = _to_b64(val)
        # Gallery images
        gallery = []
        for img in clean.get('gallery_images') or []:
            if not isinstance(img, dict):
                continue
            img_copy = dict(img)
            img_copy['image'] = _to_b64(img_copy.get('image'))
            if img_copy['image']:
                gallery.append(img_copy)
        clean['gallery_images'] = gallery
        # Ticket lines datetimes
        tickets = []
        for line in clean.get('ticket_lines') or []:
            if not isinstance(line, dict):
                continue
            line_copy = dict(line)
            line_copy['start_sale_datetime'] = _to_iso(line_copy.get('start_sale_datetime'))
            line_copy['end_sale_datetime'] = _to_iso(line_copy.get('end_sale_datetime'))
            tickets.append(line_copy)
        clean['ticket_lines'] = tickets
        return clean
    
    @http.route(['/event/apply/submit'], type='http', auth='user', website=True, methods=['POST'], csrf=True)
    def event_application_submit(self, **post):
        payload, error_code = self._build_application_payload(post)
        if error_code:
            return request.redirect(f'/event/apply?error={error_code}')
        request.session[self._application_payment_session_key()] = self._sanitize_payload_for_session(payload)
        return request.redirect('/event/apply/review')

    @http.route(['/event/apply/review'], type='http', auth='user', website=True, methods=['GET'])
    def event_application_review(self, **kwargs):
        payload = request.session.get(self._application_payment_session_key())
        if not payload:
            return request.redirect('/event/apply')
        specialty_names = []
        case_names = []
        try:
            if payload.get('specialty_ids'):
                specialty_names = request.env['event.specialty'].sudo().browse(payload.get('specialty_ids')).mapped('name')
            if payload.get('case_ids'):
                case_names = request.env['event.case'].sudo().browse(payload.get('case_ids')).mapped('name')
        except Exception:
            specialty_names = []
            case_names = []
        return request.render('event_application.event_application_review_page', {
            'application_payload': payload,
            'specialty_names': specialty_names,
            'case_names': case_names,
        })

    @http.route(['/event/apply/payment'], type='http', auth='user', website=True, methods=['GET'])
    def event_application_payment(self, **kwargs):
        payload = request.session.get(self._application_payment_session_key())
        if not payload:
            return request.redirect('/event/apply')
        if not payload.get('confirm_token'):
            payload['confirm_token'] = secrets.token_urlsafe(16)
            request.session[self._application_payment_session_key()] = payload
        required_points = int(payload.get('submission_point_cost') or 0)
        wallet = self._get_points_wallet()
        available_points = int(wallet.get_current_balance()) if wallet else 0
        payment_error_code = kwargs.get('payment_error_code')
        if required_points > 0 and available_points < required_points:
            payment_error_code = payment_error_code or 'insufficient_points'
        return request.render('event_application.event_application_payment_page', {
            'application_payload': payload,
            'required_points': required_points,
            'available_points': available_points,
            'payment_error_code': payment_error_code,
            'submit_error': kwargs.get('submit_error'),
        })

    @http.route(['/event/apply/confirm-payment'], type='http', auth='user', website=True, methods=['POST'], csrf=True)
    def event_application_confirm_payment(self, **post):
        try:
            session_key = self._application_payment_session_key()
            payload = request.session.get(session_key)
            if not payload:
                return request.redirect('/event/apply')
            posted_confirm_token = post.get('confirm_token')
            payload_confirm_token = payload.get('confirm_token')
            if (
                posted_confirm_token
                and payload_confirm_token
                and posted_confirm_token != payload_confirm_token
            ):
                _logger.warning(
                    "Event application confirm token mismatch for partner %s; proceeding with CSRF-validated submit",
                    request.env.user.partner_id.id,
                )
            request.session.pop(session_key, None)
            required_points = int(payload.get('submission_point_cost') or 0)
            wallet = self._get_points_wallet()
            available_points = int(wallet.get_current_balance()) if wallet else 0
            if required_points > 0 and available_points < required_points:
                payload['confirm_token'] = secrets.token_urlsafe(16)
                request.session[session_key] = payload
                return request.redirect('/event/apply/payment?payment_error_code=insufficient_points')
            vals = self._build_application_vals_from_payload(payload)
            application = False
            resubmit_id = int(payload.get('resubmit_application_id') or 0)
            resubmit_rec = request.env['event.application'].sudo().browse(resubmit_id) if resubmit_id else False
            if resubmit_rec and resubmit_rec.exists() and resubmit_rec.partner_id.id == request.env.user.partner_id.id and resubmit_rec.state in ('rejected', 'draft'):
                resubmit_rec.sudo().write(vals)
                application = resubmit_rec
            else:
                application = request.env['event.application'].sudo().create(vals)
            application.sudo().action_submit()
            return request.redirect('/event/apply/payment-success?' + urlencode({
                'application_id': application.id,
            }))
        except ValidationError as e:
            payload = request.session.get(session_key) or payload or {}
            payload['confirm_token'] = secrets.token_urlsafe(16)
            request.session[session_key] = payload
            return request.redirect('/event/apply/payment?' + urlencode({
                'payment_error_code': 'submit_failed',
                'submit_error': str(e),
            }))
        except Exception as e:
            payload = request.session.get(session_key) or payload or {}
            payload['confirm_token'] = secrets.token_urlsafe(16)
            request.session[session_key] = payload
            _logger.exception("Event application confirm-payment failed")
            return request.redirect('/event/apply/payment?' + urlencode({
                'payment_error_code': 'submit_failed',
                'submit_error': str(e),
            }))

    @http.route(['/event/apply/payment-success'], type='http', auth='user', website=True, methods=['GET'])
    def event_application_payment_success(self, application_id=None, **kwargs):
        application = False
        if str(application_id or '').isdigit():
            application = request.env['event.application'].sudo().browse(int(application_id))
            if not application.exists() or application.partner_id.id != request.env.user.partner_id.id:
                application = False
        return request.render('event_application.event_application_payment_success_page', {
            'application': application,
            'redirect_url': '/my/event/applications',
            'redirect_seconds': 3,
        })

    @http.route(['/my/event/application/<int:application_id>/resubmit'], type='http', auth='user', website=True)
    def event_application_resubmit(self, application_id, **kwargs):
        application = request.env['event.application'].sudo().browse(application_id)
        if (
            not application.exists()
            or application.partner_id.id != request.env.user.partner_id.id
            or application.state != 'rejected'
        ):
            return request.redirect('/my/event/applications')
        draft_payload = self._build_draft_from_application(application)
        draft_json = json.dumps(draft_payload, ensure_ascii=False)
        draft_b64 = base64.b64encode(draft_json.encode('utf-8')).decode('ascii')
        return request.render('event_application.event_application_resubmit_redirect', {
            'draft_b64': draft_b64,
        })
    
    @http.route(['/my/event/application/<int:application_id>'], type='http', auth='user', website=True)
    def event_application_detail(self, application_id, **kwargs):
        application = request.env['event.application'].browse(application_id)
        if application.partner_id.id != request.env.user.partner_id.id:
            return request.redirect('/my')
        return request.render('event_application.portal_application_detail', {
            'application': application,
            'event_notification_count': self._get_event_notification_count(),
        })

    @http.route(['/my/event/notifications'], type='http', auth='user', website=True)
    def my_event_notifications(self, **kwargs):
        show_all = str(kwargs.get('show_all') or '').strip().lower() in ('1', 'true', 'yes', 'on')
        domain = [('partner_id', '=', request.env.user.partner_id.id)]
        if not show_all:
            domain.append(('is_read', '=', False))
        notifications = request.env['event.application.notification'].sudo().search(domain)
        return request.render('event_application.portal_my_event_notifications', {
            'notifications': notifications,
            'event_notification_count': self._get_event_notification_count(),
            'show_all_notifications': show_all,
        })

    @http.route(['/my/event/notifications/read_all'], type='http', auth='user', website=True)
    def my_event_notifications_read_all(self, **kwargs):
        """Mark all notifications for the current partner as read then return to list."""
        notif_model = request.env['event.application.notification'].sudo()
        notif_model.search([('partner_id', '=', request.env.user.partner_id.id), ('is_read', '=', False)]).write({'is_read': True})
        return request.redirect('/my/event/notifications')

    @http.route(['/my/points/log'], type='http', auth='user', website=True)
    def my_points_log(self, **kwargs):
        partner = request.env.user.partner_id
        wallet_model = request.env['event.points.wallet'].sudo()
        tx_model = request.env['event.points.transaction'].sudo()

        wallet = wallet_model.search([('partner_id', '=', partner.id)], limit=1)
        balance = int(wallet.get_current_balance()) if wallet else 0
        transactions = tx_model.search([('partner_id', '=', partner.id)], order='create_date desc, id desc')

        return request.render('event_application.portal_my_points_log', {
            'wallet': wallet,
            'balance': balance,
            'transactions': transactions,
            'event_notification_count': self._get_event_notification_count(),
            'event_point_balance': balance,
        })

    @http.route(['/my/event/notification/<int:notification_id>/read'], type='http', auth='user', website=True)
    def my_event_notification_read(self, notification_id, **kwargs):
        notification = request.env['event.application.notification'].sudo().search([
            ('id', '=', notification_id),
            ('partner_id', '=', request.env.user.partner_id.id),
        ], limit=1)
        if not notification:
            return request.redirect('/my/event/notifications')
        # Force mark-as-read before any redirect to target page.
        notification.sudo().write({'is_read': True})
        if notification.action_url and str(notification.action_url).startswith('/'):
            return request.redirect(notification.action_url)
        return request.redirect('/my/event/notifications')
    
    @http.route(['/my/event/<int:event_id>/registrations'], type='http', auth='user', website=True)
    def my_event_registrations(self, event_id, **kw):
        """View registrations for an event"""
        event = request.env['event.event'].sudo().browse(event_id)
        
        # Check if user owns this event
        if event.organizer_id.id != request.env.user.partner_id.id:
            return request.redirect('/my')
        
        # Get all registrations for this event
        registrations = request.env['event.registration'].sudo().search([
            ('event_id', '=', event_id)
        ], order='create_date desc')
        
        # Calculate statistics using the 'state' field
        total_count = len(registrations)
        attended_count = len(registrations.filtered(lambda r: r.state == 'done'))
        not_attended_count = len(registrations.filtered(lambda r: r.state in ['open', 'draft']))
        attendance_rate = (attended_count / total_count * 100) if total_count else 0
        checkin_base = request.httprequest.url_root.rstrip('/')

        # Group registrations by ticket to make attendee lists clearer.
        # Pre-create groups from the event's configured ticket types so they
        # are shown even when no attendee has registered yet.
        grouped = {}
        for ticket in event.event_ticket_ids.sorted(lambda t: ((not t.is_pinned), t.sequence, t.id)):
            grouped[ticket.id] = {
                'ticket': ticket,
                'ticket_name': ticket.name or 'Unnamed Ticket',
                'registrations': request.env['event.registration'].sudo().browse(),
            }

        for registration in registrations:
            ticket = registration.event_ticket_id
            ticket_id = ticket.id or 0
            if ticket_id not in grouped:
                grouped[ticket_id] = {
                    'ticket': ticket,
                    'ticket_name': ticket.name if ticket else 'General / No Ticket',
                    'registrations': request.env['event.registration'].sudo().browse(),
                }
            grouped[ticket_id]['registrations'] |= registration

        ticket_groups = sorted(
            grouped.values(),
            key=lambda g: (
                0 if (g['ticket'] and g['ticket'].is_pinned) else 1,
                g['ticket'].sequence if g['ticket'] else 999999,
                (g['ticket_name'] or '').lower(),
            ),
        )
        for group in ticket_groups:
            group_regs = group['registrations']
            group['total_count'] = len(group_regs)
            group['attended_count'] = len(group_regs.filtered(lambda r: r.state == 'done'))
            group['not_attended_count'] = len(group_regs.filtered(lambda r: r.state in ['open', 'draft']))
        
        return request.render('event_application.portal_my_event_registrations', {
            'event': event,
            'registrations': registrations,
            'ticket_groups': ticket_groups,
            'total_count': total_count,
            'attended_count': attended_count,
            'not_attended_count': not_attended_count,
            'attendance_rate': attendance_rate,
            'checkin_base': checkin_base,
            'quote_plus': quote_plus,
            'page_name': 'event_registrations',
        })

    @http.route(['/my/event/<int:event_id>/registration/<int:registration_id>/mark'], 
                type='http', auth='user', website=True, methods=['POST'], csrf=True)
    def mark_registration_attended(self, event_id, registration_id, **post):
        """Mark a registration as attended (same as barcode scan does)"""
        event = request.env['event.event'].sudo().browse(event_id)
        
        # Check if user owns this event
        if event.organizer_id.id != request.env.user.partner_id.id:
            return request.redirect('/my')
        
        registration = request.env['event.registration'].sudo().browse(registration_id)
        if registration.event_id.id == event_id:
            registration.action_mark_attended()
        
        return request.redirect(f'/my/event/{event_id}/registrations?success=1')

    @http.route(['/my/event/<int:event_id>/registration/<int:registration_id>/unmark'], 
                type='http', auth='user', website=True, methods=['POST'], csrf=True)
    def mark_registration_not_attended(self, event_id, registration_id, **post):
        """Mark a registration as not attended"""
        event = request.env['event.event'].sudo().browse(event_id)
        
        # Check if user owns this event
        if event.organizer_id.id != request.env.user.partner_id.id:
            return request.redirect('/my')
        
        registration = request.env['event.registration'].sudo().browse(registration_id)
        if registration.event_id.id == event_id:
            registration.action_mark_not_attended()
        
        return request.redirect(f'/my/event/{event_id}/registrations?success=1')

    @http.route(['/my/event-review'], type='http', auth='user', website=True)
    def event_review(self, **kwargs):
        """Backward-compatible route: redirect to unified Applications backend view"""
        action = request.env.ref('event_application.action_event_application')
        return request.redirect(f'/web#action={action.id}')
